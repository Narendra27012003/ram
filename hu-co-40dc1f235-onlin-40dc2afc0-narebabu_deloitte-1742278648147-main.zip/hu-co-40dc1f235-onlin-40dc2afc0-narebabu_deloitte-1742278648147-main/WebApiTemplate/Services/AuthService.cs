﻿using BCrypt.Net;
using WebApiTemplate.Data;
using WebApiTemplate.DTO;
using WebApiTemplate.Helpers;
using WebApiTemplate.Models;

namespace WebApiTemplate.Services
{
    public class AuthService
    {
        private readonly ApplicationDbContext _context;
        private readonly JwtHelper _jwtHelper;

        public AuthService(ApplicationDbContext context, JwtHelper jwtHelper)
        {
            _context = context;
            _jwtHelper = jwtHelper;
        }
        public bool ChangeUserRole(int userId, string newRole)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == userId);
            if (user == null) return false; // 🔹 User not found

            user.Role = newRole; // 🔹 Assign new role
            _context.SaveChanges();
            return true; // 🔹 Role updated successfully
        }

        public string Authenticate(UserLoginDto userDto)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == userDto.Username);
            if (user == null || !BCrypt.Net.BCrypt.Verify(userDto.Password, user.PasswordHash))
            {
                return null;  // Authentication failed
            }

            return _jwtHelper.GenerateToken(user);
        }

        public string Register(UserRegisterDto userDto, string role = "StandardUser") // 🔹 Assign single role
        {
            if (_context.Users.Any(u => u.Email == userDto.Email))
            {
                return "Email already exists";
            }

            var newUser = new User
            {
                Username = userDto.Username,
                Email = userDto.Email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(userDto.Password),
                Role = role // 🔹 Assign only one role
            };

            _context.Users.Add(newUser);
            _context.SaveChanges();
            return "User registered successfully.";
        }
    }
}
