﻿using WebApiTemplate.Data;
using WebApiTemplate.DTO;
using WebApiTemplate.Models;

namespace WebApiTemplate.Services
{
    public class GenreService
    {
        private readonly ApplicationDbContext _context;

        public GenreService(ApplicationDbContext context)
        {
            _context = context;
        }

        // 🔹 Get All Genres
        public IEnumerable<Genre> GetGenres() => _context.Genres.ToList();

        // 🔹 Get a Genre by ID
        public Genre? GetGenreById(int id) => _context.Genres.FirstOrDefault(g => g.Id == id);

        // 🔹 Add a New Genre
        public void AddGenre(GenreDto genreDto)
        {
            var genre = new Genre { Name = genreDto.Name };
            _context.Genres.Add(genre);
            _context.SaveChanges();
        }

        // 🔹 Update a Genre
        public bool UpdateGenre(int id, GenreDto genreDto)
        {
            var genre = _context.Genres.FirstOrDefault(g => g.Id == id);
            if (genre == null) return false;

            genre.Name = genreDto.Name;
            _context.SaveChanges();
            return true;
        }

        // 🔹 Delete a Genre
        public bool DeleteGenre(int id)
        {
            var genre = _context.Genres.FirstOrDefault(g => g.Id == id);
            if (genre == null) return false;

            _context.Genres.Remove(genre);
            _context.SaveChanges();
            return true;
        }

        // 🔹 Assign a Genre to a Book
        public bool AssignGenreToBook(int bookId, int genreId)
        {
            if (!_context.Books.Any(b => b.Id == bookId) || !_context.Genres.Any(g => g.Id == genreId))
                return false;

            if (_context.BookGenres.Any(bg => bg.BookId == bookId && bg.GenreId == genreId))
                return false; // 🔹 Prevent duplicate assignments

            var bookGenre = new BookGenre { BookId = bookId, GenreId = genreId };
            _context.BookGenres.Add(bookGenre);
            _context.SaveChanges();
            return true;
        }

        // 🔹 Remove a Genre from a Book
        public bool RemoveGenreFromBook(int bookId, int genreId)
        {
            var bookGenre = _context.BookGenres.FirstOrDefault(bg => bg.BookId == bookId && bg.GenreId == genreId);
            if (bookGenre == null) return false;

            _context.BookGenres.Remove(bookGenre);
            _context.SaveChanges();
            return true;
        }
    }
}