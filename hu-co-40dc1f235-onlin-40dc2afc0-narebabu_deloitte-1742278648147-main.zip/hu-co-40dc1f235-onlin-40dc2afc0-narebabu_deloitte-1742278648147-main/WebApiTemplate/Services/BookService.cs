﻿using WebApiTemplate.Data;
using WebApiTemplate.DTO;
using WebApiTemplate.Models;

namespace WebApiTemplate.Services
{
    public class BookService
    {
        private readonly ApplicationDbContext _context;

        public BookService(ApplicationDbContext context)
        {
            _context = context;
        }

        // 🔹 Get all books
        public IEnumerable<Book> GetBooks() => _context.Books.ToList();

        // 🔹 Get a single book by ID
        public Book? GetBookById(int id) => _context.Books.FirstOrDefault(b => b.Id == id);

        // 🔹 Add a new book
        public void AddBook(BookDto bookDto, string? authorUsername = null)
        {
            var book = new Book
            {
                Title = bookDto.Title,
                Author = authorUsername ?? bookDto.Author, // 🔹 Assign username if provided, otherwise use DTO author
                Description = bookDto.Description,
                Genre = bookDto.Genre,
                Publisher = bookDto.Publisher,
                PublicationYear = bookDto.PublicationYear
            };

            _context.Books.Add(book);
            _context.SaveChanges();
        }

        // 🔹 Update an existing book
        public bool UpdateBook(int id, BookDto bookDto)
        {
            var book = _context.Books.FirstOrDefault(b => b.Id == id);
            if (book != null)
            {
                book.Title = bookDto.Title;
                book.Description = bookDto.Description;
                book.Genre = bookDto.Genre;
                book.Publisher = bookDto.Publisher;
                book.PublicationYear = bookDto.PublicationYear;
                _context.SaveChanges();
                return true; // 🔹 Book updated successfully
            }
            return false; // 🔹 Book not found
        }

        // 🔹 Delete a book
 
        public bool DeleteBook(int id)
        {
            var book = _context.Books.FirstOrDefault(b => b.Id == id);
            if (book != null)
            {
                _context.Books.Remove(book);
                _context.SaveChanges();
                return true; // 🔹 Book deleted successfully
            }
            return false; // 🔹 Book not found
        }

        // 🔹 Check if a book belongs to a specific author
        public bool IsBookOwner(int bookId, string username)
        {
            var book = _context.Books.FirstOrDefault(b => b.Id == bookId);
            return book != null && book.Author == username; // 🔹 Check if book belongs to the author
        }
    }
}
