﻿namespace WebApiTemplate.DTO
{
    public class GenreDto
    {
        public string Name { get; set; } = string.Empty;
    }
}