﻿using FluentValidation;
using WebApiTemplate.DTO;

namespace WebApiTemplate.Validators
{
    public class UserLoginValidator : AbstractValidator<UserLoginDto>
    {
        public UserLoginValidator()
        {
            RuleFor(user => user.Username)
                .NotEmpty().WithMessage("Username is required");

            RuleFor(user => user.Password)
                .NotEmpty().WithMessage("Password is required");
        }
    }
}
