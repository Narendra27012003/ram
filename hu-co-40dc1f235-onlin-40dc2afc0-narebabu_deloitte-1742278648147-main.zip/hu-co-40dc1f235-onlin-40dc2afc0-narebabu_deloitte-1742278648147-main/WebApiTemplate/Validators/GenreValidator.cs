﻿using FluentValidation;
using WebApiTemplate.DTO;

namespace WebApiTemplate.Validators
{
    public class GenreValidator : AbstractValidator<GenreDto>
    {
        public GenreValidator()
        {
            RuleFor(g => g.Name)
                .NotEmpty().WithMessage("Genre name is required")
                .MinimumLength(3).WithMessage("Genre name must be at least 3 characters long")
                .MaximumLength(50).WithMessage("Genre name must be less than 50 characters");
        }
    }
}