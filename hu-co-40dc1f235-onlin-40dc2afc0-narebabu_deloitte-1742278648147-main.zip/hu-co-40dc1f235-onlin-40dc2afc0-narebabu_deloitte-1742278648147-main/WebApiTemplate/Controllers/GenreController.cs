﻿
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiTemplate.DTO;
using WebApiTemplate.Services;

namespace WebApiTemplate.Controllers
{
    [Route("api/genres")]
    [ApiController]
    [Authorize(Roles = "Admin")] // 🔹 Only Admins can manage genres
    public class GenreController : ControllerBase
    {
        private readonly GenreService _genreService;
        private readonly IValidator<GenreDto> _genreValidator;

        public GenreController(GenreService genreService, IValidator<GenreDto> genreValidator)
        {
            _genreService = genreService;
            _genreValidator = genreValidator;
        }

        // 🔹 Get All Genres (Public)
        [HttpGet]
        [AllowAnonymous] // ✅ Public access
        public IActionResult GetGenres() => Ok(_genreService.GetGenres());

        // 🔹 Get a Single Genre by ID (Public)
        [HttpGet("{id}")]
        [AllowAnonymous]
        public IActionResult GetGenre(int id)
        {
            var genre = _genreService.GetGenreById(id);
            return genre != null ? Ok(genre) : NotFound(new { message = "Genre not found" });
        }

        // 🔹 Add a New Genre (Admin Only)
        [HttpPost]
        public IActionResult AddGenre([FromBody] GenreDto genreDto)
        {
            var validationResult = _genreValidator.Validate(genreDto);
            if (!validationResult.IsValid)
                return BadRequest(validationResult.Errors.Select(e => e.ErrorMessage));

            _genreService.AddGenre(genreDto);
            return Created("", new { message = "Genre added successfully" });
        }

        // 🔹 Update a Genre (Admin Only)
        [HttpPut("{id}")]
        public IActionResult UpdateGenre(int id, [FromBody] GenreDto genreDto)
        {
            var validationResult = _genreValidator.Validate(genreDto);
            if (!validationResult.IsValid)
                return BadRequest(validationResult.Errors.Select(e => e.ErrorMessage));

            if (!_genreService.UpdateGenre(id, genreDto))
                return NotFound(new { message = "Genre not found" });

            return Ok(new { message = "Genre updated successfully" });
        }

        // 🔹 Delete a Genre (Admin Only)
        [HttpDelete("{id}")]
        public IActionResult DeleteGenre(int id)
        {
            if (!_genreService.DeleteGenre(id))
                return NotFound(new { message = "Genre not found" });

            return Ok(new { message = "Genre deleted successfully" });
        }

        // 🔹 Assign a Genre to a Book (Admin Only)
        [HttpPost("assign/{bookId}/{genreId}")]
        public IActionResult AssignGenreToBook(int bookId, int genreId)
        {
            if (!_genreService.AssignGenreToBook(bookId, genreId))
                return NotFound(new { message = "Book or Genre not found, or already assigned" });

            return Ok(new { message = "Genre assigned to book successfully" });
        }

        // 🔹 Remove a Genre from a Book (Admin Only)
        [HttpDelete("remove/{bookId}/{genreId}")]
        public IActionResult RemoveGenreFromBook(int bookId, int genreId)
        {
            if (!_genreService.RemoveGenreFromBook(bookId, genreId))
                return NotFound(new { message = "Genre not assigned to book" });

            return Ok(new { message = "Genre removed from book successfully" });
        }
    }
}